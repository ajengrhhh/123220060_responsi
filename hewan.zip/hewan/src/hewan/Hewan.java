/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hewan;

/**
 *
 * @author
 */
public class Hewan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainView v = new MainView();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        System.out.println();
    }
    
}
