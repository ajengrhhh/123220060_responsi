/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author 
 */
public class datahewan {
    public String nama_pemilik;
    public String nama_hewan;
    public String jenis_hewan;
    public int nomor_telepon;
    public int durasi_titip;
    public int total_biaya;
    public int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    

    public String getNama_pemilik() {
        return nama_pemilik;
    }

    public void setNama_pemilik(String nama_pemilik) {
        this.nama_pemilik = nama_pemilik;
    }

    public String getNama_hewan() {
        return nama_hewan;
    }

    public void setNama_hewan(String nama_hewan) {
        this.nama_hewan = nama_hewan;
    }

    public String getJenis_hewan() {
        return jenis_hewan;
    }

    public void setJenis_hewan(String jenis_hewan) {
        this.jenis_hewan = jenis_hewan;
    }

    public int getNomor_telepon() {
        return nomor_telepon;
    }

    public void setNomor_telepon(int nomor_telepon) {
        this.nomor_telepon = nomor_telepon;
    }

    public int getDurasi_titip() {
        return durasi_titip;
    }

    public void setDurasi_titip(int durasi_titip) {
        this.durasi_titip = durasi_titip;
    }

    public int getTotal_biaya() {
        return total_biaya;
    }

    public void setTotal_biaya(int total_biaya) {
        this.total_biaya = total_biaya;
    }
}
